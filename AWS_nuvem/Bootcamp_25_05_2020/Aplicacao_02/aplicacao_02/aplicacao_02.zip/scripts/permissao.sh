#!/bin/bash
cd /var/www/html
chown apache:apache rds.conf.php
