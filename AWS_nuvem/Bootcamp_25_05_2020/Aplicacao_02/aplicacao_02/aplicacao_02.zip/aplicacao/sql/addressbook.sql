CREATE TABLE address (id INT(4) NOT NULL AUTO_INCREMENT PRIMARY KEY, lastname VARCHAR(30), firstname VARCHAR(30), phone VARCHAR(30), email VARCHAR(30));
INSERT INTO address (lastname, firstname, phone, email) VALUES ( "Porciuncula", "Leandro", "48 988333282", "leandro@cloudtreinamentos.com"), ( "Rodrigues", "Sandro", "48 111223344", "sandro@cloudtreinamentos.com" );
