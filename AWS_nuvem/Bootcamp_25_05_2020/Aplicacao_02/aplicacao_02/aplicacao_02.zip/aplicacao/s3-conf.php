<?php
$accessKey = 'Access key ID';
$secretKey = 'Secret access key';
$region = 'us-east-1';
$bucket = 'NOME DO BUCKET';
$arqName =  'logo.jpg';
?>
