<?php
$accessKey = 'AKIAU76L4NPJXYE4KP4S';
$secretKey = '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';
$region = 'us-east-1';
$bucket = 'imagens.bootcamp.cloud.mario';
$arqName =  'logo.jpg';
?>
